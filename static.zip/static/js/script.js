const menuElement = document.querySelector(".menu");
const closeEL = document.querySelector(".menu2");
const hederEl = document.querySelector(".site-header");

menuElement.addEventListener("click", (e) => {
    hederEl.classList.add("opened");
    hederEl.style.transition = "left 0.2s ease"; 
    hederEl.style.left = "0"; 
    e.target.style.display = "none";
    closeEL.style.display = "block";
});

closeEL.addEventListener("click", (e) => {
    hederEl.style.transition = "left 0.2s ease"; 
    hederEl.style.left = "-500px"; 
    setTimeout(() => {
        hederEl.classList.remove("opened");
    }, 500); 
    e.target.style.display = "none";
    menuElement.style.display = "block";
});

const divEls = document.querySelectorAll("div");

divEls.forEach((div, index) => {
    div.addEventListener("click", (e) => {
        console.log(e.target);
    });
});