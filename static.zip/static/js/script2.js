    
var faqItems = document.querySelectorAll(".menu-row-inner");

   
faqItems.forEach(function(item) {
    var addIcon = item.querySelector(".add");
    var removeIcon = item.querySelector(".remove");
    var paragraph = item.querySelector("p");

    addIcon.addEventListener("click", function() {
        item.classList.remove("active");
        paragraph.style.display = "block";
        addIcon.style.display = "none";
        removeIcon.style.display = "inline-block";
    });

    removeIcon.addEventListener("click", function() {
        item.classList.add("active");
        paragraph.style.display = "none";
        addIcon.style.display = "inline-block";
        removeIcon.style.display = "none";
    });
});